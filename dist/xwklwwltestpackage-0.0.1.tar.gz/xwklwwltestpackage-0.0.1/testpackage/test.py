def test():
    print("OK")
    
if __name__ == '__main__' :
    test()